# Consulta ISBN com Vite + React

Projeto simples usando a API da BrasilAPI para buscar livros por ISBN.
